package helm

const Applicationjson = "application/json"
const MultipartFormdata = "multipart/form-data"
const Contenttype = "Content-Type"
const ApiKeyHeader = "X-Api-Key"
